var $ = require('jquery');

// нашёл как делать запрос cors
// var request = require('request');
// var s = request.get('https://glavpunkt.ru/js/punkts-widget/glavpunkt.js');
